"""JIRA Data Center REST 클라이언트 — Basic 인증 + httpx.

JiraClient.java + IssueFetcher.java 포팅.
  - Basic Auth (ID + 비밀번호) → Authorization 헤더
  - /rest/api/2/{myself, search, issue/{key}, field}
  - 자체서명 인증서 대비 trust_all(verify=False) — 사내망 전용
  - search 는 maxResults 상한(보통 100)이라 페이지네이션
"""

from __future__ import annotations

import base64
from typing import Any

import httpx

# IssueFetcher.BASE_FIELDS 와 동일
BASE_FIELDS = (
    "summary,status,priority,labels,assignee,reporter,created,updated,"
    "issuetype,components,fixVersions,duedate,resolution,resolutiondate,description"
)
PAGE_SIZE = 100


class JiraError(RuntimeError):
    """JIRA 연결·인증·조회 오류."""


class JiraClient:
    def __init__(
        self,
        base_url: str,
        user: "str | None",
        password: "str | None",
        *,
        trust_all: bool = False,
        timeout: float = 60.0,
    ):
        if not base_url:
            raise JiraError("JIRA_BASE_URL 미설정 — .env 확인")
        if not user or not password:
            raise JiraError("JIRA_USER / JIRA_PASSWORD 미설정 — .env 확인")
        self.base_url = base_url.rstrip("/")
        token = base64.b64encode(f"{user}:{password}".encode("utf-8")).decode("ascii")
        self._headers = {"Authorization": f"Basic {token}", "Accept": "application/json"}
        self._http = httpx.Client(
            verify=not trust_all, timeout=timeout, follow_redirects=True
        )

    # ----- 저수준 -----
    def _get(self, path: str, params: "dict[str, Any] | None" = None) -> httpx.Response:
        return self._http.get(self.base_url + path, headers=self._headers, params=params)

    def close(self) -> None:
        self._http.close()

    # ----- 엔드포인트 -----
    def ping(self) -> "dict[str, Any]":
        """로그인 확인 — /rest/api/2/myself."""
        r = self._get("/rest/api/2/myself")
        if r.status_code != 200:
            raise JiraError(f"ping 실패 HTTP {r.status_code}: {r.text[:300]}")
        return r.json()

    def fields(self) -> "list[dict[str, Any]]":
        """전체 필드 목록 — /rest/api/2/field (커스텀필드 ID 조회용)."""
        r = self._get("/rest/api/2/field")
        if r.status_code != 200:
            raise JiraError(f"field 조회 실패 HTTP {r.status_code}: {r.text[:200]}")
        return r.json()

    def get_issue(self, key: str) -> "dict[str, Any]":
        """이슈 상세 — /rest/api/2/issue/{key}."""
        r = self._get(f"/rest/api/2/issue/{key}")
        if r.status_code != 200:
            raise JiraError(f"이슈 조회 실패 HTTP {r.status_code}: {r.text[:200]}")
        return r.json()

    def _search_page(
        self, jql: str, fields: str, start_at: int, max_results: int
    ) -> "dict[str, Any]":
        r = self._get(
            "/rest/api/2/search",
            params={
                "jql": jql,
                "fields": fields,
                "startAt": start_at,
                "maxResults": max_results,
            },
        )
        if r.status_code != 200:
            raise JiraError(
                f"search 실패 HTTP {r.status_code}\nJQL: {jql}\nBody: {r.text[:500]}"
            )
        return r.json()

    def fetch_all(
        self,
        jql: str,
        *,
        extra_field_ids: "list[str] | None" = None,
        overall_cap: int = 500,
    ) -> "dict[str, Any]":
        """JQL 결과를 페이지네이션으로 overall_cap 까지 수집 (IssueFetcher.fetchAll 포팅)."""
        fields = BASE_FIELDS
        if extra_field_ids:
            extra = ",".join(f for f in extra_field_ids if f)
            if extra:
                fields = f"{fields},{extra}"

        issues: "list[dict[str, Any]]" = []
        start_at = 0
        total = -1
        while len(issues) < overall_cap:
            page_size = min(PAGE_SIZE, overall_cap - len(issues))
            data = self._search_page(jql, fields, start_at, page_size)
            total = data.get("total", total)
            page = data.get("issues", [])
            if not page:
                break
            issues.extend(page)
            start_at += len(page)
            if total >= 0 and start_at >= total:
                break
        return {
            "jql": jql,
            "total_on_server": total,
            "fetched": len(issues),
            "issues": issues,
        }
