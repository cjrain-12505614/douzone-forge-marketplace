"""JIRA-MCP — Amaranth 10 JIRA 조회 MCP 서버 (조회 전용)."""

__version__ = "0.1.0"
