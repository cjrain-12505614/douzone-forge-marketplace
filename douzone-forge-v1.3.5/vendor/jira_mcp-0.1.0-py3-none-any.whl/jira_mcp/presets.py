"""JQL 프리셋 로딩 + 담당자 자동 결합 (Main.java 포팅).

config/jql-presets.yml 을 읽어 프리셋 JQL 을 제공하고, .env 의 JIRA_ASSIGNEES 를
`assignee in (…)` 절로 ORDER BY 앞에 AND 결합한다(Main.wrapAnd).
config 위치: JIRA_CONFIG_DIR > 레포 루트 config/ > 패키지 내 config/.
"""

from __future__ import annotations

import os
import re

import yaml


def _config_dir() -> str:
    d = os.environ.get("JIRA_CONFIG_DIR")
    if d:
        return d
    here = os.path.dirname(os.path.abspath(__file__))  # src/jira_mcp/
    pkg_cfg = os.path.join(here, "config")  # 패키지 동봉(wheel 에 포함) — 우선
    if os.path.isdir(pkg_cfg):
        return pkg_cfg
    return os.path.normpath(os.path.join(here, "..", "..", "config"))  # 개발(editable) 레포 폴백


def load_presets() -> "dict[str, dict]":
    path = os.path.join(_config_dir(), "jql-presets.yml")
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return data.get("presets", {})


def list_presets() -> "list[dict]":
    out = []
    for name, p in load_presets().items():
        out.append(
            {
                "name": name,
                "description": p.get("description", ""),
                "skip_assignee": bool(p.get("skipAssigneeFilter", False)),
            }
        )
    return out


def get_preset(name: str) -> "tuple[str, bool]":
    """(jql, skip_assignee_filter) 반환. 없으면 KeyError."""
    presets = load_presets()
    if name not in presets:
        raise KeyError(
            f"존재하지 않는 preset: {name} — 사용 가능: {', '.join(presets) or '(없음)'}"
        )
    p = presets[name]
    jql = " ".join((p.get("jql", "") or "").split())  # 멀티라인 → 한 줄 정규화
    return jql, bool(p.get("skipAssigneeFilter", False))


def build_assignee_clause(csv: str) -> str:
    if not csv or not csv.strip():
        return ""
    items = [a.strip() for a in csv.split(",") if a.strip()]
    if not items:
        return ""
    return "assignee in (" + ", ".join(items) + ")"


def wrap_and(jql: str, clause: str) -> str:
    """ORDER BY 가 있으면 그 앞에, 없으면 끝에 AND clause 삽입 (Main.wrapAnd 포팅)."""
    trimmed = (jql or "").strip()
    m = re.search(r"order\s+by", trimmed, re.IGNORECASE)
    if not m:
        return f"{trimmed} AND {clause}"
    head = trimmed[: m.start()].strip()
    tail = trimmed[m.start():]
    return f"{head} AND {clause} {tail}"
