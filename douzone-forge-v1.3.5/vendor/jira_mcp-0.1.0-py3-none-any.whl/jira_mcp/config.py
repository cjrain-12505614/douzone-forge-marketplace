"""JIRA-MCP 설정 — 환경변수/.env 에서 로드 (표준 라이브러리만).

.env 우선 로드(경량 파서, os.environ 미오염 → 변경 즉시 반영). 실제 자격증명
(JIRA_USER/PASSWORD)은 트리 밖(.env, gitignore)에만.
JIRA_ENV_FILE(절대경로) 우선 — Claude Desktop/Code 등 cwd 가 레포가 아닌 환경 대응.

설계: a10-mcp config.py 패턴 미러 (EnvLoader.java 포팅).
"""

from __future__ import annotations

import os
from dataclasses import dataclass

DEFAULT_BASE_URL = "http://jira.duzon.com:8080"


@dataclass(frozen=True)
class Settings:
    base_url: str
    user: "str | None"
    password: "str | None"
    projects: str           # 콤마 구분 (예: BC10,CSA10)
    module_field_id: str    # "모듈" 커스텀 필드 ID (예: customfield_10123)
    modules: str            # 콤마 구분 (예: 연락처,게시판,…)
    assignees: str          # 콤마 구분 — fetch 시 assignee in (…) 자동 AND
    exclude_status: str     # 콤마 구분 (참고용 — JQL 프리셋은 statusCategory 사용)
    trust_all_certs: bool   # 사내 자체서명 인증서 대비
    max_results: int        # 페이지네이션 전체 상한


def _read_dotenv(path: str) -> "dict[str, str]":
    """경량 .env 파서 — 파일을 dict 로 반환(os.environ 변경 없음)."""
    data: "dict[str, str]" = {}
    if not os.path.exists(path):
        return data
    with open(path, "r", encoding="utf-8") as fp:
        for raw in fp:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            key, val = key.strip(), val.strip().strip('"').strip("'")
            if key:
                data[key] = val
    return data


def _pick(name: str, fd: "dict[str, str]", default=None):
    """우선순위: 런처가 준 환경변수(비어있지 않음) > .env 파일 > 기본값."""
    v = os.environ.get(name)
    if v not in (None, ""):
        return v
    v = fd.get(name)
    if v not in (None, ""):
        return v
    return default


def _pick_bool(name: str, fd: "dict[str, str]", default: bool = False) -> bool:
    v = _pick(name, fd)
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "y", "on")


def _pick_int(name: str, fd: "dict[str, str]", default: int) -> int:
    v = _pick(name, fd)
    try:
        return int(v) if v not in (None, "") else default
    except (TypeError, ValueError):
        return default


def load_settings(dotenv_path: str = ".env") -> Settings:
    env_file = os.environ.get("JIRA_ENV_FILE") or dotenv_path
    fd = _read_dotenv(env_file)
    return Settings(
        base_url=_pick("JIRA_BASE_URL", fd, DEFAULT_BASE_URL),
        user=_pick("JIRA_USER", fd),
        password=_pick("JIRA_PASSWORD", fd),
        projects=_pick("JIRA_PROJECTS", fd, ""),
        module_field_id=_pick("JIRA_MODULE_FIELD_ID", fd, ""),
        modules=_pick("JIRA_MODULES", fd, ""),
        assignees=_pick("JIRA_ASSIGNEES", fd, ""),
        exclude_status=_pick("JIRA_EXCLUDE_STATUS", fd, ""),
        trust_all_certs=_pick_bool("JIRA_TRUST_ALL_CERTS", fd, False),
        max_results=_pick_int("JIRA_MAX_RESULTS", fd, 500),
    )
