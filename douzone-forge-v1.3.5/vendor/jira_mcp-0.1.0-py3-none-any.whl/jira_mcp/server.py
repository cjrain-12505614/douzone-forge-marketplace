"""JIRA-MCP 서버 진입점 — FastMCP 로 JIRA 조회 도구 노출.

실행: `jira-mcp`(콘솔 스크립트) 또는 `python -m jira_mcp.server`.
설정/.env 는 config.py (JIRA_ENV_FILE 우선). 인증은 Basic(ID/PW).
⚠️ 조회 전용 — 이슈 생성·수정·코멘트 작성 불가.

도구: ping · list_presets · fetch_issues · find_field · get_issue
"""

from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from . import presets as _presets
from .client import JiraClient, JiraError
from .config import load_settings

mcp = FastMCP("jira-mcp")


def _client() -> "tuple[JiraClient, Any]":
    """요청 시점에 .env 재로딩해 클라이언트 생성."""
    s = load_settings()
    return JiraClient(s.base_url, s.user, s.password, trust_all=s.trust_all_certs), s


# ────────────────────────── 연결·메타 ──────────────────────────
@mcp.tool()
def ping() -> "dict[str, Any]":
    """JIRA 로그인 확인(/rest/api/2/myself). 자격증명·연결 점검용."""
    client, _ = _client()
    try:
        me = client.ping()
        return {
            "ok": True,
            "name": me.get("name"),
            "displayName": me.get("displayName"),
            "emailAddress": me.get("emailAddress"),
        }
    except JiraError as e:
        return {"ok": False, "error": str(e)}
    finally:
        client.close()


@mcp.tool()
def list_presets() -> "dict[str, Any]":
    """사용 가능한 JQL 프리셋 목록.

    default·allOpen·recent7days·highPriority·bugAndImprovement·stale·inProgress·mine.
    각 프리셋은 BC10+CSA10 × 모듈 5종(연락처·게시판·업무관리·법무관리·CRM) 기준.
    """
    return {"presets": _presets.list_presets()}


# ────────────────────────── 이슈 조회 ──────────────────────────
@mcp.tool()
def fetch_issues(preset: str = "default", jql: str = "", max_results: int = 0) -> "dict[str, Any]":
    """JIRA 이슈 조회 — preset(프리셋명) 또는 jql(직접 쿼리) 중 하나.

    jql 이 주어지면 우선, 아니면 preset 사용(기본 'default').
    .env JIRA_ASSIGNEES 가 자동으로 `AND assignee in (…)` 결합(프리셋 skipAssigneeFilter=true 면 생략).
    ⚠️ 한글 필드명은 JQL 에서 쌍따옴표 필수: `"모듈" in (게시판)`.
    max_results=0 이면 .env JIRA_MAX_RESULTS(기본 500). 모듈 분포(by_module)는 JIRA_MODULE_FIELD_ID 설정 시 제공.
    """
    client, s = _client()
    try:
        if jql.strip():
            query = jql.strip()
            skip_assignee = False
        else:
            query, skip_assignee = _presets.get_preset(preset or "default")

        if not skip_assignee:
            clause = _presets.build_assignee_clause(s.assignees)
            if clause:
                query = _presets.wrap_and(query, clause)

        cap = max_results if max_results and max_results > 0 else s.max_results
        extra = [s.module_field_id] if s.module_field_id else []
        result = client.fetch_all(query, extra_field_ids=extra, overall_cap=cap)

        out = {
            "query": query,
            "total_on_server": result["total_on_server"],
            "fetched": result["fetched"],
            "module_field_id": s.module_field_id or None,
        }
        if s.module_field_id:
            out["by_module"] = _summarize_by_module(result["issues"], s.module_field_id)
        out["issues"] = [_slim_issue(i, s.module_field_id) for i in result["issues"]]
        return out
    except KeyError as e:
        return {"ok": False, "error": str(e)}
    except JiraError as e:
        return {"ok": False, "error": str(e)}
    finally:
        client.close()


@mcp.tool()
def find_field(name: str) -> "dict[str, Any]":
    """JIRA 커스텀 필드 ID 조회(/rest/api/2/field). 예: name='모듈' → customfield_XXXXX.

    .env JIRA_MODULE_FIELD_ID 를 채울 때 사용.
    """
    client, _ = _client()
    try:
        fields = client.fields()
        exact = [f for f in fields if f.get("name") == name]
        similar = [
            f for f in fields
            if name.lower() in (f.get("name") or "").lower() and f.get("name") != name
        ]
        return {
            "exact": [{"id": f["id"], "name": f["name"]} for f in exact],
            "similar": [{"id": f["id"], "name": f["name"]} for f in similar][:20],
            "hint": (f"JIRA_MODULE_FIELD_ID={exact[0]['id']}" if exact else None),
        }
    except JiraError as e:
        return {"ok": False, "error": str(e)}
    finally:
        client.close()


@mcp.tool()
def get_issue(key: str) -> "dict[str, Any]":
    """JIRA 이슈 상세 조회(/rest/api/2/issue/{key}). 예: key='CSA10-1234'."""
    client, s = _client()
    try:
        return _slim_issue(client.get_issue(key), s.module_field_id, full=True)
    except JiraError as e:
        return {"ok": False, "error": str(e)}
    finally:
        client.close()


# ────────────────────────── 헬퍼 ──────────────────────────
def _module_values(issue: "dict", field_id: str) -> "list[str]":
    """커스텀 필드에서 값 목록 추출 (IssueFetcher.extractCustomFieldValues 포팅)."""
    if not field_id:
        return []
    node = issue.get("fields", {}).get(field_id)
    out: "list[str]" = []
    if isinstance(node, list):
        for n in node:
            if isinstance(n, dict) and "value" in n:
                out.append(n["value"])
            elif isinstance(n, str):
                out.append(n)
    elif isinstance(node, dict):
        if "value" in node:
            out.append(node["value"])
        elif "name" in node:
            out.append(node["name"])
    elif isinstance(node, str):
        out.append(node)
    return out


def _summarize_by_module(issues: "list[dict]", field_id: str) -> "dict[str, int]":
    counts: "dict[str, int]" = {}
    for i in issues:
        mods = _module_values(i, field_id) or ["_unmapped"]
        for m in mods:
            counts[m] = counts.get(m, 0) + 1
    return counts


def _slim_issue(issue: "dict", field_id: str, full: bool = False) -> "dict[str, Any]":
    f = issue.get("fields", {})

    def _name(x):
        return x.get("name") if isinstance(x, dict) else x

    assignee = f.get("assignee")
    reporter = f.get("reporter")
    out: "dict[str, Any]" = {
        "key": issue.get("key"),
        "summary": f.get("summary"),
        "status": _name(f.get("status")),
        "priority": _name(f.get("priority")),
        "issuetype": _name(f.get("issuetype")),
        "assignee": assignee.get("displayName") if isinstance(assignee, dict) else None,
        "reporter": reporter.get("displayName") if isinstance(reporter, dict) else None,
        "created": f.get("created"),
        "updated": f.get("updated"),
        "labels": f.get("labels", []),
        "modules": _module_values(issue, field_id),
    }
    if full:
        out["description"] = f.get("description")
        out["components"] = [_name(c) for c in f.get("components", [])]
        out["resolution"] = _name(f.get("resolution"))
    return out


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
